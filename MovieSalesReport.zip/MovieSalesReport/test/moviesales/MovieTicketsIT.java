/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package moviesales;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class MovieTicketsTest {

    private final MovieTickets movieTickets = new MovieTickets();

    @Test
    void CalculateTotalSales_ReturnsExpectedTotalSales() {
        int[] sales = {3000, 1500, 1700};

        assertEquals(6200, movieTickets.TotalMovieSales(sales));
    }

    @Test
    void TopMovieSales_ReturnsTopMovie() {
        String[] movies = {"Napoleon", "Oppenheimer"};
        int[] totals = {6200, 6300};

        assertEquals("Oppenheimer", movieTickets.TopMovie(movies, totals));
    }
}