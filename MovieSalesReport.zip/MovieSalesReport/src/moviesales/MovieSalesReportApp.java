/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package moviesales;

/**
 *
 * @author GHOST
 */
public class MovieSalesReportApp {

    public static void main(String[] args) {
        String[] movies = {"Napoleon", "Oppenheimer"};
        String[] months = {"JAN", "FEB", "MAR"};

        // Rows represent movies; columns represent months.
        int[][] monthlySales = {
            {3000, 1500, 1700},
            {3500, 1200, 1600}
        };

        MovieTickets calculator = new MovieTickets();
        int[] totalSales = new int[movies.length];

        System.out.printf("%-15s", "Movie");
        for (String month : months) {
            System.out.printf("%10s", month);
        }
        System.out.printf("%12s%n", "TOTAL");

        for (int i = 0; i < movies.length; i++) {
            totalSales[i] = calculator.TotalMovieSales(monthlySales[i]);

            System.out.printf("%-15s", movies[i]);
            for (int sales : monthlySales[i]) {
                System.out.printf("%10d", sales);
            }
            System.out.printf("%12d%n", totalSales[i]);
        }

        System.out.println("\nTop performing movie: "
                + calculator.TopMovie(movies, totalSales));
    }
}
