/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package moviesales;

/**
 *
 * @author GHOST
 */
public class MovieTickets implements IMovieTickets {

    @Override
    public int TotalMovieSales(int[] movieTicketSales) {
        int total = 0;

        for (int sales : movieTicketSales) {
            total += sales;
        }

        return total;
    }

    @Override
    public String TopMovie(String[] movies, int[] totalSales) {
        if (movies == null || totalSales == null
                || movies.length == 0 || movies.length != totalSales.length) {
            throw new IllegalArgumentException(
                    "Movie names and sales must have matching entries.");
        }

        int topIndex = 0;

        for (int i = 1; i < totalSales.length; i++) {
            if (totalSales[i] > totalSales[topIndex]) {
                topIndex = i;
            }
        }

        return movies[topIndex];
    }
}
