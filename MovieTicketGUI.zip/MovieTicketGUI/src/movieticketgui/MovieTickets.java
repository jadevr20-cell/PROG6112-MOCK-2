/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package movieticketgui;

/**
 *
 * @author GHOST
 */
public class MovieTickets implements IMovieTickets {

    private static final double VAT_RATE = 0.14;

    @Override
    public double CalculateTotalTicketPrice(int numberOfTickets,
                                            double ticketPrice) {
        return numberOfTickets * ticketPrice * (1 + VAT_RATE);
    }

    @Override
    public boolean ValidateData(MovieTicketData data) {
        return data != null
                && data.getMovieName() != null
                && !data.getMovieName().trim().isEmpty()
                && data.getNumberOfTickets() > 0
                && Double.isFinite(data.getTicketPrice())
                && data.getTicketPrice() > 0;
    }
}